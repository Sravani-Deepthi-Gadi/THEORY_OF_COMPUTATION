from graphviz import Digraph
from copy import deepcopy
from collections import deque

debug_mode=False
use_lambda=False
lambda_symbol='_'
alphabet=None

class Expression:

    @staticmethod
    def trim(expr):
        while expr[0]=='(' and expr[-1]==')':
            expr=expr[1:-1]
        return expr
    
    @staticmethod
    def is_concatenation(c):
        return c=='(' or Expression.is_letter(c)
    @staticmethod
    def is_letter(c):
        return c in alphabet
    def __init__(self, expr):
        self.nullable=None
        self.first_pos=[]
        self.last_pos=[]
        self.item=None
        self.position=None
        self.children=[]
        if len(expr)==1 and self.is_letter(expr):
            self.item=expr
            if use_lambda:
                if self.item==lambda_symbol:
                    self.nullable=True
                else:
                    self.nullable=False
            else:
                self.nullable=False
            return
        
        star_op=-1
        or_operator=-1
        concatenation=-1
        add_operator=-1
        i=0

        while i<len(expr):
            if expr[i]=='(':
                bracket=1
                i+=1
                while bracket!=0 and i<len(expr):
                    if expr[i]=='(':
                        bracket+=1
                    if expr[i]==')':
                        bracket -=1
                    i +=1
            else:
                i +=1
            
            if i ==len(expr):
                break

            if self.is_concatenation(expr[i]):
                if concatenation== -1:
                    concatenation= i
                continue
            if expr[i]=='*':
                if star_op ==-1:
                    star_op =i
                continue
            if expr[i]=='|':
                if or_operator==-1:
                    or_operator=i
            if expr[i]=='+':
                if add_operator==-1:
                    add_operator=i
            
        
        if or_operator!=-1:
            self.item='|'
            self.children.append(Expression(self.trim(expr[:or_operator])))
            self.children.append(Expression(self.trim(expr[(or_operator + 1):])))
        elif concatenation != -1:
            self.item = '.'
            self.children.append(Expression(self.trim(expr[:concatenation])))
            self.children.append(Expression(self.trim(expr[concatenation:])))
        elif star_op != -1:
            self.item='*'
            self.children.append(Expression(self.trim(expr[:star_op])))
        elif add_operator!= -1:
            self.item='+'
            self.children.append(Expression(self.trim(expr[:add_operator])))
            remaining_expr = expr[add_operator+1:]
            if remaining_expr:
                self.children.append(Expression(remaining_expr))
        

    def calculate_functions(self,pos,followpos):
        if self.is_letter(self.item):
            self.first_pos=[pos]
            self.last_pos=[pos]
            self.position=pos
            followpos.append([self.item,[]])
            return pos+1

        for child in self.children:
            pos =child.calculate_functions(pos,followpos)

        if self.item =='.':
            if self.children[0].nullable:
                self.first_pos=sorted(list(set(self.children[0].first_pos+self.children[1].first_pos)))
            else:
                self.first_pos=deepcopy(self.children[0].first_pos)
            if self.children[1].nullable:
                self.last_pos=sorted(list(set(self.children[0].last_pos+self.children[1].last_pos)))
            else:
                self.last_pos=deepcopy(self.children[1].last_pos)
            self.nullable=self.children[0].nullable and self.children[1].nullable
            for i in self.children[0].last_pos:
                for j in self.children[1].first_pos:
                    if j not in followpos[i][1]:
                        followpos[i][1]=sorted(followpos[i][1]+[j])

        elif self.item =='|':
            self.first_pos=sorted(list(set(self.children[0].first_pos+self.children[1].first_pos)))
            self.last_pos=sorted(list(set(self.children[0].last_pos+self.children[1].last_pos)))
            self.nullable=self.children[0].nullable or self.children[1].nullable

        elif self.item=='*':
            self.first_pos=deepcopy(self.children[0].first_pos)
            self.last_pos=deepcopy(self.children[0].last_pos)
            self.nullable=True
            
            for i in self.children[0].last_pos:
                for j in self.children[0].first_pos:
                    if j not in followpos[i][1]:
                        followpos[i][1]=sorted(followpos[i][1] + [j])
        elif self.item == '+':
            self.first_pos = deepcopy(self.children[0].first_pos)
            self.last_pos = deepcopy(self.children[0].last_pos)
            self.nullable = False
            for i in self.children[0].last_pos:
                for j in self.children[0].first_pos:
                    if j not in followpos[i][1]:
                        followpos[i][1] = sorted(followpos[i][1] + [j])

        return pos

    def write_level(self, level): 
        print(str(level) + ' ' + self.item, self.first_pos, self.last_pos, self.nullable, '' if self.position is None else self.position)
        for child in self.children:
            child.write_level(level + 1)

class PatternExpression:

    def __init__(self, expr):
        self.expr = expr
        self.followpos =[]
        self.calculate()

    def calculate(self):
        positions=Expression(self.expr).calculate_functions(0, self.followpos)   
        if debug_mode:
            print(self.followpos)

    def to_dfa(self):

        def contains_hashtag(q):
            for i in q:
                if self.followpos[i][0] == '#':
                    return True
            return False

        M= []
        Q= [] 
        V= alphabet - {'#', lambda_symbol if use_lambda else ''}
        d= []
        F=[]
        q0=self.followpos[0][1]

        Q.append(q0)
        if contains_hashtag(q0):
            F.append(Q.index(q0))

        while len(Q)-len(M) > 0:
            q = [i for i in Q if i not in M][0]
            d.append({})
            M.append(q)
            for a in V:
                U=[]
                for i in q:
                    if self.followpos[i][0]==a:
                        U = U + self.followpos[i][1]
                U = sorted(list(set(U)))
                if len(U)==0:
                    continue
                if U not in Q:
                    Q.append(U)
                    if contains_hashtag(U):
                        F.append(Q.index(U))
                d[Q.index(q)][a] =Q.index(U)
        
        return DFA(Q, V,d,Q.index(q0),F)

class DFA:

    def __init__(self,Q,V,d,q0,F):
        self.Q =Q
        self.V=V
        self.d= d
        self.q0= q0
        self.F= F

    def run(self):
        while True:
            text=input("Enter a string to test (type 'exit' to stop): ")
            if text.lower() =='exit':
                break

            q =self.q0
            for i in text:
                if q>=len(self.d):
                    print('String not accepted')
                    return
                if i not in self.d[q].keys():
                    print('String not accepted')
                    return
                q=self.d[q][i]

            if q in self.F:
                print('String accepted')
            else:
                print('String not accepted')

    def visualize(self):
        dot=Digraph()
        dot.graph_attr['rankdir']='LR'
        dot.node_attr['shape']='circle'

        state_names =[chr(ord('A')+i) for i in range(len(self.Q))]

        for i, state_name in enumerate(state_names):
            dot.node(state_name, label=state_name, shape='doublecircle' if i in self.F else 'circle')

        for i, state_name in enumerate(state_names):
            transitions={symbol: [] for symbol in self.V}
            for symbol, next_state in self.d[i].items():
                next_state_name=state_names[next_state]
                transitions[symbol].append(next_state_name)
            for symbol, next_states in transitions.items():
                next_states_str=', '.join(next_states)
                dot.edge(state_name, next_states_str, label=symbol)

        dot.render(filename='dfa_visualization', format='pdf', view=True)
        
        print("\nState Transition Table:")
        print("========================")
        print("State\t", end="")
        for symbol in self.V:
            print(symbol, end="\t")
        print()
        for i, state_name in enumerate(state_names):
            print(state_name, end="\t")
            for symbol in self.V:
                if symbol in self.d[i]:
                    next_state_name = state_names[self.d[i][symbol]]
                    print(next_state_name, end="\t")
                else:
                    print("-", end="\t")
            print()
    
    def write(self):
        for i in range(len(self.Q)):
            print(i, self.d[i], 'F' if i in self.F else '')

def preprocess(expr):
    expr=clean_star_op(expr)
    expr = expr.replace(' ','')
    expr ='('+expr+')'+'#'
    while '()' in expr:
        expr=expr.replace('()','')
    return expr

def clean_star_op(expr):
    for i in range(0,len(expr)-1):
        while i<len(expr)-1 and expr[i+1] == expr[i] and expr[i] =='*':
            expr=expr[:i]+expr[i+1:]
    return expr

def generate_alphabet(expr):
    return set(expr)-set('()|*+')
input_expr=input("Enter a regular expression: ")
preprocessed_expr=preprocess(input_expr)
alphabet = generate_alphabet(preprocessed_expr)
extra =''
alphabet= alphabet.union(set(extra))
pattern_expr= PatternExpression(preprocessed_expr)
if debug_mode:
    pattern_expr.write()
dfa=pattern_expr.to_dfa()
dfa.visualize()
dfa.run()
